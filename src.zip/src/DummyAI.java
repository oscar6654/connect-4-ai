import connectK.CKPlayer;
import connectK.BoardModel;
import java.awt.Point;
import java.util.Random;

public class DummyAI extends CKPlayer {

	public DummyAI(byte player, BoardModel state) {
		super(player, state);
		teamName = "UpdatedDummyAI";
	}

	@Override
	public Point getMove(BoardModel state) {
		int i, j, count;
		double fori,forj;
		count = state.getWidth()*state.getHeight();
		while(count!=0)
		{
		// get random no;
		fori = Math.random()*state.getWidth();
		forj = Math.random()*state.getHeight();
		// convert double to int
		i = (int)fori;
		j = (int)forj;
		//check it already selected or not
		if(state.getSpace(i, j) == 0)
			return new Point(i,j);
		else
			count--;
		}
		return null;
	}

	@Override
	public Point getMove(BoardModel state, int deadline) {
		return getMove(state);
	}
}
